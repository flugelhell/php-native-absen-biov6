<?php
$users = array(
    'yyt' => array(
        'password' => 'yyt',
        'nip' => '0824892',
        'pin' => '824892'
    ),
);
